ALTER TABLE ActivityLog
DROP COLUMN IPAddress
select * from ActivityLog