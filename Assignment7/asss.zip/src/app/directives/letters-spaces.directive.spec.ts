import { LettersSpacesDirective } from './letters-spaces.directive';

describe('LettersSpacesDirective', () => {
  it('should create an instance', () => {
    const directive = new LettersSpacesDirective();
    expect(directive).toBeTruthy();
  });
});
